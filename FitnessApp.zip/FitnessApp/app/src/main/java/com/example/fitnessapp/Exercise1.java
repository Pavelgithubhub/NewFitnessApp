package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;
import android.animation.ObjectAnimator;


public class Exercise1 extends AppCompatActivity {
    ImageView backExercise1ImageView;
    TextView textViewTimer;
    AppCompatButton btnStartTimer;

    //НАЧАЛО  Анимация картинки
    public class MainActivity extends AppCompatActivity {

        private ImageView imageView;
        private int currentImage = 1; // Индикатор текущей картинки

        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            imageView = findViewById(R.id.imageView);

            // Создаем массив с ресурсами изображений
            final int[] images = {R.drawable.image_1, R.drawable.image_2};

            // Устанавливаем слушатель нажатия на изображение
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Инвертируем индикатор текущей картинки
                    currentImage = 1 - currentImage;

                    // Создаем анимацию смены картинок
                    ObjectAnimator anim = ObjectAnimator.ofInt(imageView, "imageResource", images[currentImage]);
                    anim.setDuration(500); // Устанавливаем длительность анимации в миллисекундах
                    anim.start(); // Запускаем анимацию
                }
            });
        }
    }
//КОНЕЦ  Анимация картинки

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(Exercise1.this, MainActivity.class));
        finish();
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise1);

//НАЧАЛО Кнопка старта таймера
        CountDownTimer countDownTimer = new CountDownTimer(30000, 1000) {
            @Override
            public void onTick(long l) {
                int minutes = (int) l/1000/60;
                int seconds = (int) l/1000 - minutes*60;
                if (seconds < 10) {
                    textViewTimer.setText(minutes + ":0" + seconds);
                }
                else {
                    textViewTimer.setText(minutes + ":" + seconds);
                }
            }

            @Override
            public void onFinish() {
            }
        };

        btnStartTimer = findViewById(R.id.btnStartTimer);
        btnStartTimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countDownTimer.start();
            }
        });
//КОНЕЦ Кнопка старта таймера

        textViewTimer = findViewById(R.id.textViewTimer);

        //НАЧАЛО   Устанавливается рандомное фоновое изображение
        backExercise1ImageView = findViewById(R.id.backExercise1ImageView);
        Random random = new Random();
        int randomImageNumber = 1 + random.nextInt(5);
        switch (randomImageNumber){
            case 1: backExercise1ImageView.setImageResource(R.drawable.fon_1); break;
            case 2: backExercise1ImageView.setImageResource(R.drawable.fon_2); break;
            case 3: backExercise1ImageView.setImageResource(R.drawable.fon_3); break;
            case 4: backExercise1ImageView.setImageResource(R.drawable.fon_4); break;
            case 5: backExercise1ImageView.setImageResource(R.drawable.fon_5); break;
        }
//КОНЕЦ   Устанавливается рандомное фоновое изображение

    }
}